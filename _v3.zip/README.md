# BjDrive 🛒🛵

Marketplace de livraison à domicile au **Bénin** : les clients commandent auprès d'enseignes vérifiées (supermarché, hypermarché, kiosque, pharmacie…) et se font livrer, avec **suivi du livreur en temps réel**, **paiement KkiaPay** (Mobile Money / Moov Money / carte) et **commission plateforme de 10 %**.

## Organisation du dépôt (monorepo)

```
BjDrive/
  backend/            API NestJS + Prisma + PostgreSQL/PostGIS  (voir backend/README.md)
  frontend/           Application web PWA (React) — à rebrancher sur l'API
  docker-compose.yml  Base de données + API + Web, en une commande
```

## Démarrage

```bash
docker compose up --build
```
- API : http://localhost:3007/api
- Web : http://localhost:8080
- Base : PostgreSQL/PostGIS sur le port 5432

Le super-admin est créé au démarrage (identifiants dans les variables d'environnement, voir `backend/.env.example`).

## Parcours couverts par le backend

**Client** — se connecte, choisit une enseigne vérifiée, remplit son panier, paie en une fois (produits + livraison + 10 % de commission), suit son livreur en temps réel, valide la réception par un **code**.

**Livreur** — voit les commandes payées **proches de lui**, en choisit jusqu'à **5 par jour** (plafond configurable), récupère au magasin (un créneau de livraison est alors proposé au client), partage sa position GPS, clôture avec le code de réception. Il voit ses **gains estimés du jour**.

**Manager d'enseigne** — crée sa boutique (en attente de **vérification**), la positionne sur la carte, gère ses produits et stocks (manuellement ou par **import**), renseigne ses coordonnées de versement.

**Super-admin (propriétaire)** — **vérifie les enseignes** (visite sur place / appel vidéo) avant publication, paramètre les **tarifs de livraison, la commission et le plafond de livraisons/jour**, gère les comptes, et suit les **KPIs** (volume, commission encaissée).

## État d'avancement

- ✅ **Backend complet** : modèle de données, 4 rôles, cycle de commande, commission & répartition, proximité PostGIS, plafond livreur, vérification des enseignes, paiement KkiaPay, temps réel, super-admin. Dockerisé.
- ⏳ **Prochaine étape** : rebrancher l'application `frontend/` (aujourd'hui en version démo) sur cette API, intégrer le widget de paiement KkiaPay et l'interface super-admin.

Voir **`backend/README.md`** pour la liste des endpoints et les détails techniques.
